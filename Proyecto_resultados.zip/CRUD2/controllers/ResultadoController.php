<?php
require_once('../models/ResultadoModel.php');
require_once('../BD/configuracion_bd.php');

class Database{
    private $host;
    private $username;
    private $password;
    private $database;
    private $connection;

    public function __construct($host, $username, $password, $database)
    {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;
        $this->connection = new mysqli($host, $username, $password, $database);

        if ($this->connection->connect_error) {
            die("Error de conexión a la base de datos: " . $this->connection->connect_error);
        }
    }

    public function query($sql)
    {
        return $this->connection->query($sql);
    }

    public function close()
    {
        $this->connection->close();
    }
}

class ResultadoContorller{
    private $resultadoModel;
    private $db;

    public function __construct($database)
    {
        $this->db = $database; // Inicializa la instancia de la base de datos
        // $this->resultadoModel = new ResultadoModel($database); // Inicializa la instancia de ResultadoModel
    }

    public function verResultados()
    {
        $resultados = $this->resultadoModel->obtenerResultados();
        require_once('../views/ver_resultados_view.php');
    }

    public function crearResultado($deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones)
    {
        // Validar datos del formulario, por ejemplo, que no estén vacíos

        if (empty($deporte) || empty($equipoLocal) || empty($equipoVisitante) || empty($marcador) || empty($fecha) || empty($lugar)) {
            header("Location: ../public/index.php?action=verResultados&error=Por favor, complete todos los campos obligatorios.");
            return;
        }

        // Crear el resultado en el modelo
        $resultadoCreado = $this->resultadoModel->crearResultado($deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones);

        if ($resultadoCreado) {
            // Redirigir con un mensaje de éxito
            header("Location: ../public/index.php?action=verResultados&success=Resultado creado correctamente");
        } else {
            // Mostrar un mensaje de error si la creación falla
            header("Location: ../public/index.php?action=verResultados&error=Error al crear el resultado");
        }
    }

    public function editarResultado($id)
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtener datos del formulario
            $deporte = $_POST["deporte"];
            $equipoLocal = $_POST["equipoLocal"];
            $equipoVisitante = $_POST["equipoVisitante"];
            $marcador = $_POST["marcador"];
            $fecha = $_POST["fecha"];
            $lugar = $_POST["lugar"];
            $observaciones = $_POST["observaciones"];

            // Validar datos del formulario, por ejemplo, que no estén vacíos
            if (empty($deporte) || empty($equipoLocal) || empty($equipoVisitante) || empty($marcador) || empty($fecha) || empty($lugar)) {
                header("Location: ../public/index.php?action=verResultados&error=Por favor, complete todos los campos obligatorios.");
                return;
            }

            // Actualizar resultado en el modelo
            $resultadoActualizado = $this->resultadoModel->editarResultado($id, $deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones);

            if ($resultadoActualizado) {
                // Redirigir a la página de ver resultados con un mensaje de éxito
                header("Location: ../public/index.php?action=verResultados&success=Resultado actualizado correctamente");
            } else {
                // Mostrar un mensaje de error si la actualización falla
                header("Location: ../public/index.php?action=verResultados&error=Error al actualizar el resultado");
            }
        } else {
            // Obtener detalles del resultado y mostrar formulario de edición
            $resultado = $this->resultadoModel->obtenerResultadoPorId($id);

            if ($resultado) {
                require_once('../views/header.php');
                require_once('../views/editar_resultado_view.php');
                require_once('../views/footer.php');
            } else {
                // Mostrar un mensaje de error si el resultado no se encuentra
                header("Location: ../public/index.php?action=verResultados&error=Resultado no encontrado o no válido.");
            }
        }
    }

    public function eliminarResultado($id)
    {
        // Eliminar resultado en el modelo
        $resultadoEliminado = $this->resultadoModel->eliminarResultado($id);

        if ($resultadoEliminado) {
            // Redirigir a la página de ver resultados con un mensaje de éxito
            header("Location: ../public/index.php?action=verResultados&success=Resultado eliminado correctamente");
        } else {
            // Mostrar un mensaje de error si la eliminación falla
            header("Location: ../public/index.php?action=verResultados&error=Error al eliminar el resultado");
        }
    }

    public function verDetalleResultado($id)
    {
        // Obtener detalles del resultado y mostrar vista de detalle
        $resultado = $this->resultadoModel->obtenerResultadoPorId($id);

        if ($resultado) {
            require_once('../views/header.php');
            require_once('../views/ver_detalle_view.php');
            require_once('../views/footer.php');
        } else {
            // Mostrar un mensaje de error si el resultado no se encuentra
            header("Location: ../public/index.php?action=verResultados&error=Resultado no encontrado o no válido.");
        }
    }

    public function obtenerResultadoPorId($id)
    {
        $sql = "SELECT * FROM resultados2 WHERE id = '$id'";

        $resultado = $this->db->query($sql);

        if ($resultado->num_rows > 0) {
            return $resultado->fetch_assoc();
        } else {
            return null; // No se encontró ningún resultado
        }
    }
}



class ResultadoController {
    private $resultadoModel;
    private $db;

    public function __construct($database)
    {
        $this->db = $database; // Inicializa la instancia de la base de datos
        // $this->resultadoModel = new ResultadoModel($database); // Inicializa la instancia de ResultadoModel
    }
    public function verResultados()
    {
        // $resultados = $this->resultadoModel->obtenerResultados();
        require_once('../views/ver_resultados_view.php');
    }

    public function crearResultado($deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones)
    {
        // Validar datos del formulario, por ejemplo, que no estén vacíos

        if (empty($deporte) || empty($equipoLocal) || empty($equipoVisitante) || empty($marcador) || empty($fecha) || empty($lugar)) {
            header("Location: ../public/index.php?action=verResultados&error=Por favor, complete todos los campos obligatorios.");
            return;
        }

        // Crear el resultado en el modelo
        $resultadoCreado = $this->resultadoModel->crearResultado($deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones);

        if ($resultadoCreado) {
            // Redirigir con un mensaje de éxito
            header("Location: ../public/index.php?action=verResultados&success=Resultado creado correctamente");
        } else {
            // Mostrar un mensaje de error si la creación falla
            header("Location: ../public/index.php?action=verResultados&error=Error al crear el resultado");
        }
    }

    public function editarResultado($id)
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtener datos del formulario
            $deporte = $_POST["deporte"];
            $equipoLocal = $_POST["equipoLocal"];
            $equipoVisitante = $_POST["equipoVisitante"];
            $marcador = $_POST["marcador"];
            $fecha = $_POST["fecha"];
            $lugar = $_POST["lugar"];
            $observaciones = $_POST["observaciones"];

            // Validar datos del formulario, por ejemplo, que no estén vacíos
            if (empty($deporte) || empty($equipoLocal) || empty($equipoVisitante) || empty($marcador) || empty($fecha) || empty($lugar)) {
                header("Location: ../public/index.php?action=verResultados&error=Por favor, complete todos los campos obligatorios.");
                return;
            }

            // Actualizar resultado en el modelo
            $resultadoActualizado = $this->resultadoModel->editarResultado($id, $deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones);

            if ($resultadoActualizado) {
                // Redirigir a la página de ver resultados con un mensaje de éxito
                header("Location: ../public/index.php?action=verResultados&success=Resultado actualizado correctamente");
            } else {
                // Mostrar un mensaje de error si la actualización falla
                header("Location: ../public/index.php?action=verResultados&error=Error al actualizar el resultado");
            }
        } else {
            // Obtener detalles del resultado y mostrar formulario de edición
            $resultado = $this->resultadoModel->obtenerResultadoPorId($id);

            if ($resultado) {
                require_once('../views/header.php');
                require_once('../views/editar_resultado_view.php');
                require_once('../views/footer.php');
            } else {
                // Mostrar un mensaje de error si el resultado no se encuentra
                header("Location: ../public/index.php?action=verResultados&error=Resultado no encontrado o no válido.");
            }
        }
    }

    public function eliminarResultado($id)
    {
        // Eliminar resultado en el modelo
        $resultadoEliminado = $this->resultadoModel->eliminarResultado($id);

        if ($resultadoEliminado) {
            // Redirigir a la página de ver resultados con un mensaje de éxito
            header("Location: ../public/index.php?action=verResultados&success=Resultado eliminado correctamente");
        } else {
            // Mostrar un mensaje de error si la eliminación falla
            header("Location: ../public/index.php?action=verResultados&error=Error al eliminar el resultado");
        }
    }

    public function verDetalleResultado($id)
    {
        // Obtener detalles del resultado y mostrar vista de detalle
        $resultado = $this->resultadoModel->obtenerResultadoPorId($id);

        if ($resultado) {
            require_once('../views/header.php');
            require_once('../views/ver_detalle_view.php');
            require_once('../views/footer.php');
        } else {
            // Mostrar un mensaje de error si el resultado no se encuentra
            header("Location: ../public/index.php?action=verResultados&error=Resultado no encontrado o no válido.");
        }
    }

    public function obtenerResultadoPorId($id)
    {
        $sql = "SELECT * FROM resultados2 WHERE id = '$id'";

        $resultado = $this->db->query($sql);

        if ($resultado->num_rows > 0) {
            return $resultado->fetch_assoc();
        } else {
            return null; // No se encontró ningún resultado
        }
    }
}