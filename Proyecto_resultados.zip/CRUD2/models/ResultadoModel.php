<?
// require_once('../controllers/ResultadoController.php');s
require_once('../BD/configuracion_bd.php');

class ResultadoModel{
    private $db;

    public function __construct($database)
    {
        $this->db = $database;
    }

    public function eliminarResultado($id)
    {
        $sql = "DELETE FROM resultados2 WHERE id = '$id'";

        return $this->db->query($sql);
    }

    public function obtenerResultados()
    {
        $sql = "SELECT * FROM resultados2";
        $resultados = [];

        $resultado = $this->db->query($sql);

        if ($resultado) {
            while ($fila = $resultado->fetch_assoc()) {
                $resultados[] = $fila;
            }
        }

        return $resultados;
    }

    public function obtenerResultadoPorId($id)
    {
        $sql = "SELECT * FROM resultados2 WHERE id = '$id'";
        $resultado = $this->db->query($sql);

        if ($resultado && $resultado->num_rows == 1) {
            return $resultado->fetch_assoc();
        }

        return null;
    }

    public function crearResultado($deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones)
    {
        $sql = "INSERT INTO resultados2 (deporte, equipoLocal, equipoVisitante, marcador, fecha, lugar, observaciones)
                VALUES ('$deporte', '$equipoLocal', '$equipoVisitante', '$marcador', '$fecha', '$lugar', '$observaciones')";

        return $this->db->query($sql);
    }

    public function editarResultado($id, $deporte, $equipoLocal, $equipoVisitante, $marcador, $fecha, $lugar, $observaciones)
    {
        $sql = "UPDATE resultados2 SET 
                deporte = '$deporte',
                equipoLocal = '$equipoLocal',
                equipoVisitante = '$equipoVisitante',
                marcador = '$marcador',
                fecha = '$fecha',
                lugar = '$lugar',
                observaciones = '$observaciones'
                WHERE id = '$id'";

        return $this->db->query($sql);
    }
}
?>