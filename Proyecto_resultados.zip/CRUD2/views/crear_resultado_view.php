<!DOCTYPE html>
<html>
<head>
    <title>Crear Resultado de Fútbol</title>
</head>
<body>
    <?php require_once('header.php'); ?> <!-- Incluye el encabezado -->
    <center style="margin-top: 5%;">
    <h1>Crear Resultado de Fútbol</h1>
    <form action="../public/index.php" method="POST">
        <div class="div3">
            <label for="deporte">Deporte:</label>
            <input type="text" id="deporte" name="deporte" required>
        </div>

        <div class="div1">
        <label for="equipoLocal">Equipo Local:</label>
        <input type="text" id="equipoLocal" name="equipoLocal" required>
        </div>

        <div class="div2">
        <label for="equipoVisitante">Equipo Visitante:</label>
        <input type="text" id="equipoVisitante" name="equipoVisitante" required>
        </div>

        <div class="div4">
        <label for="marcador">Marcador:</label>
        <input type="text" id="marcador" name="marcador" required>
        </div>

        <div class="div5">
        <label for="fecha">Fecha:</label>
        <input type="date" id="fecha" name="fecha" required>
        </div>

        <div class="div6">
        <label for="lugar">Lugar:</label>
        <input type="text" id="lugar" name="lugar" required>
        </div>

        <div class="div7">
        <label for="observaciones">Observaciones:</label>
        <textarea id="observaciones" name="observaciones"></textarea>
        </div>

        <div class="div8">
        <button type="submit"><h3 style="font-size: 1.3rem;">Crear Resultado</h3></button>
        </div>
    </form>

    </center>

    <?php require_once('footer.php'); ?> <!-- Incluye el pie de página -->
</body>
</html>



<style>
body{
    background-color: yellow;
}

form{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(4, 1fr);
    grid-column-gap: 20px;
    grid-row-gap: 20px;
    width: 50%;
    /* margin-top: 3%; */
}

form div{
    border: solid;
    background-color: black;
    /* padding-top: 20px; */
    /* padding-bottom: 20px; */
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 2%;
}

.div1 { grid-area: 1 / 1 / 2 / 2; }
.div2 { grid-area: 1 / 2 / 2 / 3; }
.div3 { grid-area: 2 / 1 / 3 / 2; }
.div4 { grid-area: 2 / 2 / 3 / 3; }
.div5 { grid-area: 3 / 1 / 4 / 2; }
.div6 { grid-area: 3 / 2 / 4 / 3; }
.div7 { grid-area: 4 / 1 / 5 / 3; }
.div8 {
    grid-area: 5 / 1 / 6 / 3;
    background-color: transparent;
    border: none;
 }

label{
    font-size: 1.5rem;
    color: yellow;
    font-weight: 900;
}

input{
    width: 150px;
    height: 75%;
    padding: 10px;
    color: black;
    font-weight: 600;
}

textarea{
    width: 50%;
    height: 75px;
    padding: 10px;
    color: black;
    font-weight: 600;
}

button{
    width: 75%;
    height: 75px;
    background-color: yellow;
    border: solid black;
}

</style>