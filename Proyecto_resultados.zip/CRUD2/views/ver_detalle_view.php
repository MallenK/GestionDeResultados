<!DOCTYPE html>
<html>
<head>
    <title>Detalle del Resultado de Partidos</title>
</head>
<body>
    <?php require_once('header.php'); ?> <!-- Incluye el encabezado -->

    <center style="margin-top: 5%;">

    <h1>Detalle del Resultado de Fútbol</h1>
    <div class="form">
        <div class="div1">
            <p>Deporte: <?php echo $resultado['deporte']; ?></p>
        </div>
        <div class="div2">
            <p>Equipo Local: <?php echo $resultado['equipoLocal']; ?></p>
        </div>
        
        <div class="div3">
            <p>Equipo Visitante: <?php echo $resultado['equipoVisitante']; ?></p>
        </div>
        
        <div class="div4">
            <p>Marcador: <?php echo $resultado['marcador']; ?></p>
        </div>
        
        <div class="div5">
            <p>Fecha: <?php echo $resultado['fecha']; ?></p>
        </div>

        <div class="div6">
            <p>Lugar: <?php echo $resultado['lugar']; ?></p>
        </div>

        <div class="div7">
            <p>Observaciones: <?php echo $resultado['observaciones']; ?></p>
        </div>
    </div>

    <!-- <div class="botonVerResultados"><a href="index.php?action=verResultados">Volver a Ver Resultados</a></div> -->

    </center>

    
</body>
</html>


<style>

body{
    background-color: yellow;
}

.form{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(4, 1fr);
    grid-column-gap: 20px;
    grid-row-gap: 20px;
    width: 50%;
    /* margin-top: 3%; */
}

.form div{
    border: solid;
    background-color: black;
    /* padding-top: 20px; */
    /* padding-bottom: 20px; */
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 2%;
}

.div1 { grid-area: 1 / 1 / 2 / 2; }
.div2 { grid-area: 1 / 2 / 2 / 3; }
.div3 { grid-area: 2 / 1 / 3 / 2; }
.div4 { grid-area: 2 / 2 / 3 / 3; }
.div5 { grid-area: 3 / 1 / 4 / 2; }
.div6 { grid-area: 3 / 2 / 4 / 3; }
.div7 { grid-area: 4 / 1 / 5 / 3; }
.div8 { grid-area: 5 / 1 / 6 / 3; }

div p{
    color: yellow;
    font-size: 1.5rem;
    font-weight: 900;
}

.botonVerResultados{
    display: flex;
    justify-content: center;
    margin-top: 5%;
    border: solid;
    width: 200px;
}

</style>