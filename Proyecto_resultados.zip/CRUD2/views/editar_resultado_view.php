<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Resultado de Fútbol</title>
</head>
<body>
    <?php require_once('header.php'); ?> <!-- Incluye el encabezado -->

    <center>
        <h1>Editar Resultado de Fútbol</h1>

        <?php if (isset($resultado) && is_array($resultado)) { ?>
            <form action="index.php?action=verResultados" method="POST">
                <input type="hidden" name="resultado_id" value="<?php echo $resultado['id']; ?>">

                <div class="div1">
                    <label for="deporte">Deporte:</label>
                    <input type="text" id="deporte" name="deporte" value="<?php echo $resultado['deporte']; ?>" required><br>
                </div>

                <div class="div2">
                    <label for="equipoLocal">Equipo Local:</label>
                    <input type="text" id="equipoLocal" name="equipoLocal" value="<?php echo $resultado['equipoLocal']; ?>" required><br>
                </div>

                <div class="div3">
                    <label for="equipoVisitante">Equipo Visitante:</label>
                    <input type="text" id="equipoVisitante" name="equipoVisitante" value="<?php echo $resultado['equipoVisitante']; ?>" required><br>
                </div>

                <div class="div4">
                    <label for="marcador">Marcador:</label>
                    <input type="text" id="marcador" name="marcador" value="<?php echo $resultado['marcador']; ?>" required><br>
                </div>

                <div class="div5">
                    <label for="fecha">Fecha:</label>
                    <input type="date" id="fecha" name="fecha" value="<?php echo $resultado['fecha']; ?>" required><br>
                </div>

                <div class="div6">
                    <label for="lugar">Lugar:</label>
                    <input type="text" id="lugar" name="lugar" value="<?php echo $resultado['lugar']; ?>" required><br>
                </div>

                <div class="div7">
                    <label for="observaciones">Observaciones:</label>
                    <textarea id="observaciones" name="observaciones"><?php echo $resultado['observaciones']; ?></textarea><br>
                </div>

                <div class="div8">
                    <button type="submit"> <h3 style="font-size: 1.3rem;">Guardar Cambios</h3></button>
                </div>
            </form>
        <?php } else { ?>
            <p>Resultado no encontrado o no válido.</p>
        <?php } ?>

        <?php require_once('footer.php'); ?> <!-- Incluye el pie de página -->
    </center>
</body>
</html>



<style>
body{
    background-color: yellow;
}

form{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(4, 1fr);
    grid-column-gap: 20px;
    grid-row-gap: 20px;
    width: 50%;
    /* margin-top: 3%; */
}

form div{
    border: solid;
    background-color: black;
    /* padding-top: 20px; */
    /* padding-bottom: 20px; */
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 2%;
}

.div1 { grid-area: 1 / 1 / 2 / 2; }
.div2 { grid-area: 1 / 2 / 2 / 3; }
.div3 { grid-area: 2 / 1 / 3 / 2; }
.div4 { grid-area: 2 / 2 / 3 / 3; }
.div5 { grid-area: 3 / 1 / 4 / 2; }
.div6 { grid-area: 3 / 2 / 4 / 3; }
.div7 { grid-area: 4 / 1 / 5 / 3; }
.div8 { 
    grid-area: 5 / 1 / 6 / 3; 
    background-color: transparent;
    border: none;
}

label{
    font-size: 1.5rem;
    color: yellow;
    font-weight: 900;
}

input{
    width: 150px;
    height: 75%;
    padding: 10px;
    color: black;
    font-weight: 600;
}

textarea{
    width: 50%;
    height: 75px;
}

button{
    width: 75%;
    height: 75px;
    background-color: yellow;
    border: solid black;
}

</style>