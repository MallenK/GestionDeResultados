<?php
// Establecer la zona horaria para las fechas y horas de registro
date_default_timezone_set('America/New_York'); // Cambia 'America/New_York' a la zona horaria que desees

// Función para registrar errores en el archivo de registro
function registrarError($mensaje) {
    $archivoRegistro = 'errores.log'; // Nombre del archivo de registro de errores
    $fechaHora = date('Y-m-d H:i:s'); // Fecha y hora actual
    $registro = "[$fechaHora] $mensaje\n"; // Formato del registro de error

    // Abre el archivo de registro en modo de escritura al final del archivo
    if ($handle = fopen($archivoRegistro, 'a')) {
        // Escribe el registro en el archivo de registro de errores
        fwrite($handle, $registro);
        fclose($handle);
    } else {
        // No se pudo abrir el archivo de registro, puedes agregar un manejo de errores adicional aquí si es necesario
    }
}
?>
