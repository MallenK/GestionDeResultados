<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se proporcionó un ID válido para editar
    if (isset($_POST["resultado_id"]) && is_numeric($_POST["resultado_id"])) {
        $resultado_id = $_POST["resultado_id"];

        // Obtener los datos del formulario
        $deporte = $_POST["deporte"];
        $equipoLocal = $_POST["equipoLocal"];
        $equipoVisitante = $_POST["equipoVisitante"];
        $marcador = $_POST["marcador"];
        $fecha = $_POST["fecha"];
        $lugar = $_POST["lugar"];

        // Conexión a la base de datos
        $conn = new mysqli("localhost", "root", "", "resultados_futbol2");

        if ($conn->connect_error) {
            die("Error de conexión: " . $conn->connect_error);
        }

        // Sentencia SQL para actualizar el resultado
        $sql = "UPDATE resultados2 SET
                deporte = '$deporte',
                equipo_local = '$equipoLocal',
                equipo_visitante = '$equipoVisitante',
                marcador = '$marcador',
                fecha = '$fecha',
                lugar = '$lugar'
                WHERE id = $resultado_id";

        if ($conn->query($sql) === TRUE) {
            echo "Resultado actualizado exitosamente";
        } else {
            echo "Error al actualizar el resultado: " . $conn->error;
        }

        $conn->close();
    } else {
        echo "ID de resultado no válido.";
    }
}
?>
