<?php
require_once('header.php'); // Incluye el encabezado
require_once('../controllers/ResultadoController.php'); // Incluye el controlador

// Crear una instancia del controlador y el modelo
$database = new Database("localhost", "root", "", "resultados_futbol2");
$controller = new ResultadoController($database);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Ver Resultados de Partidos</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <?php require_once('header.php'); ?> <!-- Incluye el encabezado -->

    <center style="margin-top: 5%;">
    
    
    <h1 class="tituloVerResultado">Ver Resultados de Partidos</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Deporte</th>
            <th>Equipo Local</th>
            <th>Equipo Visitante</th>
            <th>Marcador</th>
            <th>Fecha</th>
            <th>Lugar</th>
            <th>Observaciones</th>
        </tr>
        <?php
        // $resultados = $controller->verResultados(); // Llama al método del controlador para obtener los resultados
        foreach ($resultados as $resultado): 
        ?>
        <tr>
            <td><?php echo $resultado['id']; ?></td>
            <td><?php echo $resultado['deporte']; ?></td>
            <td><?php echo $resultado['equipoLocal']; ?></td>
            <td><?php echo $resultado['equipoVisitante']; ?></td>
            <td><?php echo $resultado['marcador']; ?></td>
            <td><?php echo $resultado['fecha']; ?></td>
            <td><?php echo $resultado['lugar']; ?></td>
            <td class="observaciones"><?php echo $resultado['observaciones']; ?></td>
            <td class="botoness">
                <a href="index.php?action=verDetalleResultado&id=<?php echo $resultado['id']; ?>">Ver Detalle</a>
                <a href="index.php?action=editarResultado&id=<?php echo $resultado['id']; ?>">Editar</a>
                <a href="index.php?action=eliminarResultado&id=<?php echo $resultado['id']; ?>">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    </center>

    <?php require_once('footer.php');?> <!-- Incluye el pie de página -->
</body>
</html>



<style>

.tituloVerResultado{
    display: flex;
    justify-content: center;
}

table{
    display: flex;
    justify-content: center;
    text-align: center;
    font-family: 'Montserrat', sans-serif;
}

th{
    border: solid;
    width: 100px;
    padding: 5px;
    background-color: black;
    color: yellow;
}

td{
    padding: 10px;
    justify-content: center;
    font-weight: 600;
}

.botoness a{
    color: black;
    text-decoration: none;
    border: solid;
    padding: 10px;
    background-color: black;
    color: yellow;
}

.observaciones{
    text-align: left;
    width: 260px;
}

</style>