<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de Partidos</title>
</head>
<body>

    <header>
        <nav>
            <div>
                <h1>CONTROL DE PARTITS </h1>
            </div>
            <div class="botones">
                <div class="boton">
                    <h2><a href="../public/index.php">Ver resultados</a></h2>
                </div>
                <div class="boton">
                    <h2> <a href="../views/crear_resultado_view.php">Crear Resultado</a></h2>
                </div>
            </div>
        </nav>
    </header>
    
</body>
</html>


<style>

nav{
    display: flex;
    flex-direction: row;
    background-color: yellow;
    justify-content: space-around;
}

.botones{
    display: flex;
    justify-content: space-around;
}

.boton{
    margin-right: 5%;
    border: solid;
    width: 240px;
    justify-content: center;
    display: flex;
    background-color: black;
}

.boton a{
    color: yellow;
    text-decoration: none;

}

</style>