<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "resultados_futbol2";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// // Ejemplo de inserción (Create)
// $equipoLocal = "Equipo A";
// $equipoVisitante = "Equipo B";
// $marcador = "2-1";
// $fecha = "2023-08-24";
// $lugar = "Estadio XYZ";
// $observaciones = "Lorem Ipsum";

// $sqlInsert = "INSERT INTO resultados2 (equipoLocal, equipoVisitante, marcador, fecha, lugar, observaciones)
//               VALUES ('$equipoLocal', '$equipoVisitante', '$marcador', '$fecha', '$lugar', '$observaciones')";

// if ($conn->query($sqlInsert) === TRUE) {
//     echo "Nuevo resultado creado exitosamente";
// } else {
//     echo "Error: " . $sqlInsert . "<br>" . $conn->error;
// }

// Cierre de la conexión
// $conn->close();
?>
