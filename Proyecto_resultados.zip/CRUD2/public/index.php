<?php
// Incluye los archivos necesarios
require_once('../BD/configuracion_bd.php'); // Configuración de la base de datos
require_once('../models/ResultadoModel.php'); // Modelo de Resultado
require_once('../controllers/ResultadoController.php'); // Controlador de Resultado

// Configurar la conexión a la base de datos (Database.php)
$database = new Database('localhost', 'root', '', 'resultados_futbol2');


// Crear una instancia del controlador (ResultadoController)
$controller = new ResultadoController($database);

// Determinar la acción a realizar
if (isset($_GET['action'])) {
    $action = $_GET['action']; // Obtener la acción desde la URL

    // Enrutamiento según la acción solicitada
    switch ($action) {
        case 'verResultados':
            $resultados = $controller->verResultados();
            require_once('../views/ver_resultados_view.php'); // Cargar la vista de ver resultados
            break;
        case 'crearResultado':
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Procesar creación de resultado (por ejemplo, guardar datos del formulario en la base de datos)
                // ...
            } else {
                require_once('../views/header.php'); // Encabezado común de la página
                require_once('../views/crear_resultado_view.php'); // Cargar la vista de creación de resultados
                require_once('../views/footer.php'); // Pie de página común
            }
            break;
        case 'editarResultado':
            if (isset($_GET['id']) && is_numeric($_GET['id'])) {
                $id = $_GET['id'];
                $controller->editarResultado($id);
            } else {
                // Manejar el caso de ID no válido
                echo "ID de resultado no válido para la edición.";
            }
            break;
        case 'eliminarResultado':
            if (isset($_GET['id']) && is_numeric($_GET['id'])) {
                $id = $_GET['id'];
                $controller->eliminarResultado($id);
            } else {
                // Manejar el caso de ID no válido
                echo "ID de resultado no válido para la eliminación.";
            }
            break;
        case 'verDetalleResultado':
            if (isset($_GET['id']) && is_numeric($_GET['id'])) {
                $id = $_GET['id'];
                $controller->verDetalleResultado($id);
            } else {
                // Manejar el caso de ID no válido
                echo "ID de resultado no válido para ver el detalle.";
            }
            break;
        default:
            $controller->verResultados(); // Acción por defecto: ver resultados
            break;
    }
} else {
    // Si no se especifica una acción, mostrar la lista de resultados por defecto
    $resultados = $controller->verResultados();
    require_once('../views/ver_resultados_view.php'); // Cargar la vista de ver resultados
}
?>



<style>

body{
    background-color: yellow;
}

.botonCrearResultado{
  display: flex;
  justify-content: center;
  margin-top: 5%;
  border: solid;
  width: 200px;
}

.linkCrearResultado{
    text-decoration: none;
    color: black;
}
</style>